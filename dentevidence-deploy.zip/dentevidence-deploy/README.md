# DentEvidence v0.4

AI clinical decision support для стоматологов на основе доказательной медицины.

## Локальный запуск

```bash
npm install
npm run dev
```

## Деплой на Vercel

1. Загрузи папку на GitHub
2. Зайди на vercel.com → Import Git Repository
3. Нажми Deploy

## Переменные окружения

Приложение использует Anthropic API напрямую из браузера (через артефакт).
Для production добавь прокси или используй Vite env variables.
